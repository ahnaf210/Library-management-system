import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class ViewBooks extends JFrame {

    public ViewBooks() {
        setTitle("View All Books");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        add(scrollPane, BorderLayout.CENTER);

        // Read books from books.txt
        ArrayList<String> bookList = FileIO.readFile("books.txt");

        if (bookList.isEmpty()) {
            textArea.setText("No books found in the library.");
        } else {
            StringBuilder displayText = new StringBuilder();
            displayText.append("Book ID\t\tTitle\t\tAuthor\n");
            displayText.append("--------------------------------------------------\n");
            for (String line : bookList) {
                String[] parts = line.split(",");
                if (parts.length >= 3) {
                    displayText.append(parts[0]).append("\t\t")
                               .append(parts[1]).append("\t\t")
                               .append(parts[2]).append("\n");
                }
            }
            textArea.setText(displayText.toString());
        }
    }
}