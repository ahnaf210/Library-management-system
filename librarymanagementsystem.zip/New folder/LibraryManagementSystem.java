import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LibraryManagementSystem extends JFrame {

    public LibraryManagementSystem() {
        setTitle("Library Management System");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Load background image
        ImageIcon bgImage = new ImageIcon("background.jpg");
        JLabel background = new JLabel(bgImage);
        background.setLayout(null);
        setContentPane(background);

        // Button for each feature
        JButton addBookBtn = new JButton("Add Book");
        addBookBtn.setBounds(50, 50, 200, 40);
        background.add(addBookBtn);

        JButton viewBooksBtn = new JButton("View All Books");
        viewBooksBtn.setBounds(50, 100, 200, 40);
        background.add(viewBooksBtn);

        JButton searchBookBtn = new JButton("Search Book");
        searchBookBtn.setBounds(50, 150, 200, 40);
        background.add(searchBookBtn);

        JButton deleteBookBtn = new JButton("Delete Book");
        deleteBookBtn.setBounds(50, 200, 200, 40);
        background.add(deleteBookBtn);

        JButton issueBookBtn = new JButton("Issue Book");
        issueBookBtn.setBounds(50, 250, 200, 40);
        background.add(issueBookBtn);

        JButton issuedBooksBtn = new JButton("Issued Books List");
        issuedBooksBtn.setBounds(50, 300, 200, 40);
        background.add(issuedBooksBtn);

        JButton updateBookBtn = new JButton("Update Book Info");
        updateBookBtn.setBounds(50, 350, 200, 40);
        background.add(updateBookBtn);

        JButton exitBtn = new JButton("Exit");
        exitBtn.setBounds(50, 400, 200, 40);
        background.add(exitBtn);

        // Action Listeners
        addBookBtn.addActionListener(e -> new AddBook().setVisible(true));
        viewBooksBtn.addActionListener(e -> new ViewBooks().setVisible(true));
        searchBookBtn.addActionListener(e -> new SearchBook().setVisible(true));
        deleteBookBtn.addActionListener(e -> new DeleteBook().setVisible(true));
        issueBookBtn.addActionListener(e -> new IssueBook().setVisible(true));
        issuedBooksBtn.addActionListener(e -> new IssuedBooks().setVisible(true));
        updateBookBtn.addActionListener(e -> new UpdateBooks().setVisible(true));
        exitBtn.addActionListener(e -> System.exit(0));

        setVisible(true);
    }
}