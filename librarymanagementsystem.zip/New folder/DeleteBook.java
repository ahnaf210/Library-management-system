import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;

public class DeleteBook extends JFrame {

    private JTextField bookIdField;

    public DeleteBook() {
        setTitle("Delete Book");
        setSize(400, 200);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel label = new JLabel("Enter Book ID to Delete:");
        label.setBounds(30, 30, 200, 25);
        add(label);

        bookIdField = new JTextField();
        bookIdField.setBounds(30, 60, 250, 25);
        add(bookIdField);

        JButton deleteButton = new JButton("Delete");
        deleteButton.setBounds(290, 60, 80, 25);
        add(deleteButton);

        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String bookId = bookIdField.getText().trim();

                if (bookId.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter a Book ID.");
                    return;
                }

                ArrayList<String> books = FileIO.readFile("books.txt");
                boolean removed = false;

                for (int i = 0; i < books.size(); i++) {
                    String[] parts = books.get(i).split(",");
                    if (parts.length > 0 && parts[0].equalsIgnoreCase(bookId)) {
                        books.remove(i);
                        removed = true;
                        break;
                    }
                }

                if (removed) {
                    FileIO.writeFile("books.txt", books);
                    JOptionPane.showMessageDialog(null, "Book deleted successfully.");
                } else {
                    JOptionPane.showMessageDialog(null, "Book ID not found.");
                }
            }
        });
    }
}