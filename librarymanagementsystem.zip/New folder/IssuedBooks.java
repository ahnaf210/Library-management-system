import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class IssuedBooks extends JFrame {

    private JTable table;

    public IssuedBooks() {
        setTitle("Issued Books List");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        String[] columnNames = { "Student Name", "Student ID", "Book Name", "Issue Date" };
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        loadIssuedBooks(model);
    }

    private void loadIssuedBooks(DefaultTableModel model) {
        ArrayList<String> lines = FileIO.readFile("issuedbook.txt");
        for (String line : lines) {
            String[] parts = line.split(",", 4); // split into 4 parts
            if (parts.length == 4) {
                model.addRow(parts);
            }
        }
    }
}