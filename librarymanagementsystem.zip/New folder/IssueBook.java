import javax.swing.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class IssueBook extends JFrame {

    private JTextField studentNameField, studentIdField, bookNameField, dateField;

    public IssueBook() {
        setTitle("Issue Book");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel nameLabel = new JLabel("Student Name:");
        nameLabel.setBounds(30, 30, 100, 25);
        add(nameLabel);

        studentNameField = new JTextField();
        studentNameField.setBounds(150, 30, 200, 25);
        add(studentNameField);

        JLabel idLabel = new JLabel("Student ID:");
        idLabel.setBounds(30, 70, 100, 25);
        add(idLabel);

        studentIdField = new JTextField();
        studentIdField.setBounds(150, 70, 200, 25);
        add(studentIdField);

        JLabel bookLabel = new JLabel("Book Name:");
        bookLabel.setBounds(30, 110, 100, 25);
        add(bookLabel);

        bookNameField = new JTextField();
        bookNameField.setBounds(150, 110, 200, 25);
        add(bookNameField);

        JLabel dateLabel = new JLabel("Issue Date (YYYY-MM-DD):");
        dateLabel.setBounds(30, 150, 200, 25);
        add(dateLabel);

        dateField = new JTextField(new SimpleDateFormat("yyyy-MM-dd").format(new Date())); // default to today
        dateField.setBounds(230, 150, 120, 25);
        add(dateField);

        JButton issueButton = new JButton("Issue Book");
        issueButton.setBounds(130, 200, 120, 30);
        add(issueButton);

        issueButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String studentName = studentNameField.getText().trim();
                String studentId = studentIdField.getText().trim();
                String bookName = bookNameField.getText().trim();
                String issueDate = dateField.getText().trim();

                if (studentName.isEmpty() || studentId.isEmpty() || bookName.isEmpty() || issueDate.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill in all fields.");
                    return;
                }

                String entry = studentName + "," + studentId + "," + bookName + "," + issueDate;
                FileIO.appendLine("issuedbook.txt", entry);

                JOptionPane.showMessageDialog(null, "Book issued successfully.");
                studentNameField.setText("");
                studentIdField.setText("");
                bookNameField.setText("");
                dateField.setText(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
            }
        });
    }
}