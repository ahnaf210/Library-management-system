import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;

public class SearchBook extends JFrame {

    private JTextField searchField;
    private JTextArea resultArea;

    public SearchBook() {
        setTitle("Search Book");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel searchLabel = new JLabel("Enter Book ID / Title / Author:");
        searchLabel.setBounds(30, 30, 250, 25);
        add(searchLabel);

        searchField = new JTextField();
        searchField.setBounds(30, 60, 300, 25);
        add(searchField);

        JButton searchButton = new JButton("Search");
        searchButton.setBounds(340, 60, 100, 25);
        add(searchButton);

        resultArea = new JTextArea();
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);
        scrollPane.setBounds(30, 100, 410, 230);
        add(scrollPane);

        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String query = searchField.getText().trim().toLowerCase();
                if (query.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Enter a search term.");
                    return;
                }

                ArrayList<String> books = FileIO.readFile("books.txt");
                StringBuilder results = new StringBuilder();
                boolean found = false;

                for (String book : books) {
                    if (book.toLowerCase().contains(query)) {
                        results.append(book).append("\n");
                        found = true;
                    }
                }

                if (found) {
                    resultArea.setText("Matching Results:\n\n" + results.toString());
                } else {
                    resultArea.setText("No matching book found.");
                }
            }
        });
    }
}