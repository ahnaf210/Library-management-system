
public class main {
    public static void main(String[] args) {
        // Initialize sample files with data if not present
        FileIO.createBooksTemplate();
        FileIO.createIssuedBookTemplate();

        // Show the login screen first
        login loginWindow = new login();
        loginWindow.setVisible(true);
    }
}