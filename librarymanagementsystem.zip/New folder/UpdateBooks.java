import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;

public class UpdateBooks extends JFrame {

    private JTextField bookIdField, bookTitleField, bookAuthorField;

    public UpdateBooks() {
        setTitle("Update Book Info");
        setSize(400, 250);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel idLabel = new JLabel("Book ID:");
        idLabel.setBounds(30, 30, 100, 25);
        add(idLabel);

        bookIdField = new JTextField();
        bookIdField.setBounds(140, 30, 200, 25);
        add(bookIdField);

        JLabel titleLabel = new JLabel("New Book Title:");
        titleLabel.setBounds(30, 70, 100, 25);
        add(titleLabel);

        bookTitleField = new JTextField();
        bookTitleField.setBounds(140, 70, 200, 25);
        add(bookTitleField);

        JLabel authorLabel = new JLabel("New Author Name:");
        authorLabel.setBounds(30, 110, 120, 25);
        add(authorLabel);

        bookAuthorField = new JTextField();
        bookAuthorField.setBounds(140, 110, 200, 25);
        add(bookAuthorField);

        JButton updateBtn = new JButton("Update Book");
        updateBtn.setBounds(130, 160, 120, 30);
        add(updateBtn);

        updateBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String bookId = bookIdField.getText().trim();
                String newTitle = bookTitleField.getText().trim();
                String newAuthor = bookAuthorField.getText().trim();

                if (bookId.isEmpty() || newTitle.isEmpty() || newAuthor.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill in all fields.");
                    return;
                }

                ArrayList<String> books = FileIO.readFile("books.txt");
                boolean updated = false;

                for (int i = 0; i < books.size(); i++) {
                    String line = books.get(i);
                    String[] parts = line.split(",", 3);
                    if (parts.length == 3 && parts[0].equals(bookId)) {
                        // Update title and author
                        books.set(i, bookId + "," + newTitle + "," + newAuthor);
                        updated = true;
                        break;
                    }
                }

                if (updated) {
                    FileIO.writeFile("books.txt", books);
                    JOptionPane.showMessageDialog(null, "Book info updated successfully.");
                    bookIdField.setText("");
                    bookTitleField.setText("");
                    bookAuthorField.setText("");
                } else {
                    JOptionPane.showMessageDialog(null, "Book ID not found.");
                }
            }
        });
    }
}