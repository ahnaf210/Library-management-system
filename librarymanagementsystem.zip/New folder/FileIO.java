
import java.io.*;
import java.util.ArrayList;

public class FileIO {

    // Reads all lines from a file and returns as ArrayList<String>
    public static ArrayList<String> readFile(String filename) {
        ArrayList<String> lines = new ArrayList<>();
        File file = new File(filename);

        try {
            // Create file if it doesn't exist
            if (!file.exists()) {
                file.createNewFile();
            }

            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line.trim());
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lines;
    }

    // Overwrites the file with provided lines
    public static void writeFile(String filename, ArrayList<String> lines) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename, false))) {
            for (String line : lines) {
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Appends a single line to the file
    public static void appendLine(String filename, String line) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename, true))) {
            bw.write(line);
            bw.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Initialize sample books if books.txt is empty or missing
    public static void createBooksTemplate() {
        File file = new File("books.txt");
        try {
            if (!file.exists() || file.length() == 0) {
                ArrayList<String> sampleBooks = new ArrayList<>();
                sampleBooks.add("B101,The Alchemist,Paulo Coelho");
                sampleBooks.add("B102,Java Programming,Herbert Schildt");
                sampleBooks.add("B103,Harry Potter and the Sorcerer's Stone,J.K. Rowling");
                writeFile("books.txt", sampleBooks);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Initialize sample issued books if issuedbook.txt is empty or missing
    public static void createIssuedBookTemplate() {
        File file = new File("issuedbook.txt");
        try {
            if (!file.exists() || file.length() == 0) {
                ArrayList<String> sampleIssued = new ArrayList<>();
                sampleIssued.add("Orpita Akter,221234,The Alchemist,2025-05-26");
                sampleIssued.add("Rahim Uddin,231145,Java Programming,2025-05-25");
                writeFile("issuedbook.txt", sampleIssued);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}