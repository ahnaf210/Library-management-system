import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;

public class AddBook extends JFrame {

    private JTextField bookIDField, titleField, authorField;

    public AddBook() {
        setTitle("Add New Book");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel bookIDLabel = new JLabel("Book ID:");
        bookIDLabel.setBounds(30, 30, 100, 25);
        add(bookIDLabel);

        bookIDField = new JTextField();
        bookIDField.setBounds(140, 30, 200, 25);
        add(bookIDField);

        JLabel titleLabel = new JLabel("Title:");
        titleLabel.setBounds(30, 70, 100, 25);
        add(titleLabel);

        titleField = new JTextField();
        titleField.setBounds(140, 70, 200, 25);
        add(titleField);

        JLabel authorLabel = new JLabel("Author:");
        authorLabel.setBounds(30, 110, 100, 25);
        add(authorLabel);

        authorField = new JTextField();
        authorField.setBounds(140, 110, 200, 25);
        add(authorField);

        JButton addButton = new JButton("Add Book");
        addButton.setBounds(140, 160, 120, 30);
        add(addButton);

        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String bookID = bookIDField.getText().trim();
                String title = titleField.getText().trim();
                String author = authorField.getText().trim();

                if (bookID.isEmpty() || title.isEmpty() || author.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill in all fields.");
                    return;
                }

                String bookLine = bookID + "," + title + "," + author;
                FileIO.appendLine("books.txt", bookLine);

                JOptionPane.showMessageDialog(null, "Book added successfully!");
                bookIDField.setText("");
                titleField.setText("");
                authorField.setText("");
            }
        });
    }
}